package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import java.util.Arrays;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

import java.util.Arrays;

public class MainActivity extends AppCompatActivity {
    // Declare UI elements
    EditText dataInput;
    EditText labelInput;
    EditText testInput;
    EditText kInput;
    TextView resultText;
    Button predictButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        // Find UI elements by ID
        dataInput = findViewById(R.id.data_input);
        labelInput = findViewById(R.id.label_input);
        testInput = findViewById(R.id.test_input);
        kInput = findViewById(R.id.k_input);
        resultText = findViewById(R.id.result_text);
        predictButton = findViewById(R.id.predict_button);

        // Set click listener for predict button
        predictButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Get input values
                String dataString = dataInput.getText().toString();
                String labelString = labelInput.getText().toString();
                String testString = testInput.getText().toString();
                int k = Integer.parseInt(kInput.getText().toString());

                // Parse input values
                double[][] trainSet = { parseDataString(dataString) };
                int[] trainLabels = parseLabelString(labelString);
                double[] testInstance = parseTestString(testString);

                // Predict label
                int predictedLabel = KNN.predict(trainSet, trainLabels, testInstance, k);

                // Display result
                resultText.setText("Predicted label: " + predictedLabel);
            }
        });
    }

    // Parse a comma-separated string of data into a double array
    private double[] parseDataString(String dataString) {
        String[] dataStrings = dataString.split(",");
        double[] data = new double[dataStrings.length];
        for (int i = 0; i < dataStrings.length; i++) {
            data[i] = Double.parseDouble(dataStrings[i]);
        }
        return data;
    }

    // Parse a comma-separated string of labels into an integer array
    private int[] parseLabelString(String labelString) {
        String[] labelStrings = labelString.split(",");
        int[] labels = new int[labelStrings.length];
        for (int i = 0; i < labelStrings.length; i++) {
            labels[i] = Integer.parseInt(labelStrings[i]);
        }
        return labels;
    }

    // Parse a comma-separated string of test data into a double array
    private double[] parseTestString(String testString) {
        String[] testStrings = testString.split(",");
        double[] test = new double[testStrings.length];
        for (int i = 0; i < testStrings.length; i++) {
            test[i] = Double.parseDouble(testStrings[i]);
        }
        return test;
    }
}

package com.example.myapplication;

public class KNN {
    public static int predict(double[][] trainSet, int[] trainLabels, double[] testInstance, int k) {
        // Compute distances between test instance and all training instances
        double[] distances = new double[trainSet.length];
        for (int i = 0; i < trainSet.length; i++) {
            distances[i] = distance(trainSet[i], testInstance);
        }

        // Find k nearest neighbors
        int[] indices = indicesOfSmallest(distances, k);

        // Count the number of each label in the k nearest neighbors
        int[] labelCounts = new int[100]; // Assume labels are integers 0-9
        for (int i = 0; i < k; i++) {
            int label = trainLabels[indices[i]];
            labelCounts[label]++;
        }

        // Determine the most frequent label among the k nearest neighbors
        int maxCount = -1;
        int predictedLabel = -1;
        for (int i = 0; i < 100; i++) {
            if (labelCounts[i] > maxCount) {
                maxCount = labelCounts[i];
                predictedLabel = i;
            }
        }

        return predictedLabel;
    }

    // Compute Euclidean distance between two vectors
    private static double distance(double[] a, double[] b) {
        double sum = 0;
        for (int i = 0; i < Math.min(a.length, b.length); i++) {
            double diff = a[i] - b[i];
            sum += diff * diff;
        }
        return Math.sqrt(sum);
    }

    // Find the indices of the k smallest elements in an array
    private static int[] indicesOfSmallest(double[] a, int k) {
        int[] indices = new int[k];
        for (int i = 0; i < k; i++) {
            indices[i] = i;
        }
        for (int i = k; i < a.length; i++) {
            int j = indexOfLargest(indices, a);
            if (a[i] < a[j]) {
                indices[j] = i;
            }
        }
        return indices;
    }

    // Find the index of the largest element in an array
    private static int indexOfLargest(int[] a, double[] b) {
        int index = 0;
        double max = Double.NEGATIVE_INFINITY;
        for (int i = 0; i < a.length; i++) {
            double value = b[a[i]];
            if (value > max) {
                index = i;
                max = value;
            }
        }
        return a[index];
    }
}
